# This file allows mySql connection using pymysql
import pymysql

pymysql.install_as_MySQLdb()